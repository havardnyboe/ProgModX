# impoerterer nødvendige bobloteker
import csv
import matplotlib.pyplot as plt
import numpy as np

# lager tomme lister som skal fylles med data fra csv dokumentet
t = []
a_tot = []
a_x = []
a_y = []

with open("2020/16-17 Import fra .csv/Innleveringsoppgave/akselerasjonsdata_semi.csv", "r") as csv_file: # åpner csv filen
    askelerasjon_data = csv.reader(csv_file, delimiter = ";")
    i = 0 # teller for linjenummer  
    for l in askelerasjon_data:
        if i == 0: # leser navnene fra første linjen i dokumentet
            x_navn = str(l[0]) # tilordner x_navn navnet til x-asken
            y1_navn = str(l[1]) # tilordner y1_navn navnet til a_x grafen
            y2_navn = str(l[2]) # tilordner y2_navn navnet til a_y grafen
        else:
            t.append(float(l[0])) # legger til sekundene i t-lista
            a_x.append(float(l[1])) # legger til x-retning i a_x lista
            a_y.append(float(l[2])) # legger itl y-retning i a_y lista
        i += 1

for i in range(len(t)):
    a_tot.append(np.sqrt(a_x[i]**2+a_y[i]**2)) # regner ut den totale akselerasjonen


plt.title("Akselerasjonen til en partikkel etter 10 sekunder")
# plotter grafene
plt.plot(t, a_x, label=y1_navn)
plt.plot(t, a_y, label=y2_navn)
plt.plot(t, a_tot, label="Total Akselerasjon")
plt.grid() # lager rutenett
# setter navn på aksene
plt.xlabel(x_navn + " (sekunder)")
plt.ylabel("Akselerasjon (m/s)")

plt.legend()
plt.show()
