# a)
print("\na)")
for i in range(1, 7):
    print(i)

# b)
print("\nb)")
for i in range(15, 0, -1):
    if i % 3 == 0: 
        print(i)

# c)
print("\nc)")
n = 15
while n >= 0:
    print(n)
    n -=1